import{a as t}from"../chunks/entry.BGmKWs5H.js";export{t as start};
